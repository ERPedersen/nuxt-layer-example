<script setup>
const { name } = useLayerAComposable()
</script>

<template>
  {{ name }}
</template>
