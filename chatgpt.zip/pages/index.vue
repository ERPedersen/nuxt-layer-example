<template>
  <div>
    <p>
      <NuxtLink to="/blog">Blog layer</NuxtLink>
    </p>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>
